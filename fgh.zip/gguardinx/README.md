# GuardianX – AI-Powered Real-Time Emergency Detection & Response System
Java backend + ML (logistic regression, pure Java) + MySQL 8.0 + HTML/CSS/JS dashboard. No Maven needed.

## Run (from this folder)
    javac -d out src/*.java
    java -cp out Main            # Windows & Linux/Mac, in-memory storage
Open http://localhost:8080 – create an account on the login page, then sign in.

## With MySQL (database "guardianx")
1. In MySQL: `CREATE DATABASE guardianx;`
2. Put `mysql-connector-j-8.x.jar` into `lib/`
3. Set password: `set GX_DB_PASS=yourpassword` (Windows) / `export GX_DB_PASS=...` (Linux/Mac)
4. Compile and run with the jar on the classpath:
   - Windows: `java -cp "out;lib/*" Main`
   - Linux/Mac: `java -cp "out:lib/*" Main`
Console prints "GuardianX database connected." when it works. Tables are created automatically.
Optional env vars: GX_DB_URL, GX_DB_USER.

## How it works
Sensor readings (heart rate, SpO2, temperature, impact, motionless time) -> POST /api/predict -> ML risk score
-> if risk >= 60% an alert is logged in MySQL and every registered contact is notified
(see `Main.predict`; replace the println with an SMS/email API such as Twilio for real delivery).

## Pages
login.html, register.html (public) | index.html = Dashboard, monitor.html = Live Monitor (ML), alerts.html, contacts.html (after login)

Contacts and alerts are stored per user account (owner = login email), so each user has their own emergency contacts.
