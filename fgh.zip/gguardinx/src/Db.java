import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

record Alert(long id, String time, String user, String type, double risk, String severity, String details) {}
record Contact(long id, String name, String phone) {}

/** MySQL storage (database "guardianx"). Falls back to memory if MySQL/Connector-J is unavailable. */
public class Db {
    static Connection c;
    static final Map<String, List<Alert>> A = new HashMap<>();
    static final Map<String, List<Contact>> C = new HashMap<>();
    static final AtomicLong ids = new AtomicLong();

    static String env(String k, String d) { String v = System.getenv(k); return v == null ? d : v; }

    static void init() {
        try {
            c = DriverManager.getConnection(env("GX_DB_URL", "jdbc:mysql://localhost:3306/guardianx"),
                    env("GX_DB_USER", "root"), env("GX_DB_PASS", ""));
            try (Statement s = c.createStatement()) {
                s.execute("CREATE TABLE IF NOT EXISTS users(id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(80), email VARCHAR(120) UNIQUE, pass_hash VARCHAR(200))");
                s.execute("CREATE TABLE IF NOT EXISTS contacts(id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(80), phone VARCHAR(30))");
                s.execute("CREATE TABLE IF NOT EXISTS alerts(id INT AUTO_INCREMENT PRIMARY KEY, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "
                        + "user_name VARCHAR(80), type VARCHAR(60), risk DOUBLE, severity VARCHAR(10), details VARCHAR(255))");
            }
            // add per-user "owner" column (also upgrades tables created by earlier versions)
            for (String t : new String[]{"contacts", "alerts"})
                try (Statement s2 = c.createStatement()) { s2.execute("ALTER TABLE " + t + " ADD COLUMN owner VARCHAR(120)"); } catch (SQLException ignore) {}
            System.out.println("GuardianX database connected.");
        } catch (Exception e) {
            c = null;
            System.out.println("MySQL unavailable (" + e.getMessage() + ") - using in-memory storage.");
        }
    }

    static final Map<String, String[]> U = new HashMap<>();

    static String hash(String pw, byte[] salt) throws Exception {
        var f = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        byte[] h = f.generateSecret(new javax.crypto.spec.PBEKeySpec(pw.toCharArray(), salt, 65536, 256)).getEncoded();
        return Base64.getEncoder().encodeToString(salt) + ":" + Base64.getEncoder().encodeToString(h);
    }

    static synchronized boolean addUser(String name, String email, String pw) {
        try {
            byte[] salt = new byte[16];
            new java.security.SecureRandom().nextBytes(salt);
            String h = hash(pw, salt);
            if (c != null) {
                try (PreparedStatement p = c.prepareStatement("INSERT INTO users(name,email,pass_hash) VALUES(?,?,?)")) {
                    p.setString(1, name); p.setString(2, email); p.setString(3, h); p.executeUpdate();
                    return true;
                }
            }
            if (U.containsKey(email)) return false;
            U.put(email, new String[]{name, h});
            return true;
        } catch (SQLIntegrityConstraintViolationException e) { return false;
        } catch (Exception e) { System.out.println("DB error: " + e.getMessage()); return false; }
    }

    /** returns the user's name if credentials are valid, else null */
    static synchronized String checkUser(String email, String pw) {
        try {
            String name = null, h = null;
            if (c != null) {
                try (PreparedStatement p = c.prepareStatement("SELECT name,pass_hash FROM users WHERE email=?")) {
                    p.setString(1, email);
                    ResultSet r = p.executeQuery();
                    if (r.next()) { name = r.getString(1); h = r.getString(2); }
                }
            } else if (U.containsKey(email)) { name = U.get(email)[0]; h = U.get(email)[1]; }
            if (h == null) return null;
            byte[] salt = Base64.getDecoder().decode(h.split(":")[0]);
            return hash(pw, salt).equals(h) ? name : null;
        } catch (Exception e) { return null; }
    }

    static synchronized void addContact(String owner, String name, String phone) {
        try {
            if (c != null) {
                try (PreparedStatement p = c.prepareStatement("INSERT INTO contacts(name,phone,owner) VALUES(?,?,?)")) {
                    p.setString(1, name); p.setString(2, phone); p.setString(3, owner); p.executeUpdate();
                }
            } else C.computeIfAbsent(owner, k -> new ArrayList<>()).add(new Contact(ids.incrementAndGet(), name, phone));
        } catch (SQLException e) { System.out.println("DB error: " + e.getMessage()); }
    }

    static synchronized List<Contact> contacts(String owner) {
        if (c == null) return new ArrayList<>(C.getOrDefault(owner, List.of()));
        List<Contact> l = new ArrayList<>();
        try (PreparedStatement p = c.prepareStatement("SELECT id,name,phone FROM contacts WHERE owner=? ORDER BY id")) {
            p.setString(1, owner);
            ResultSet r = p.executeQuery();
            while (r.next()) l.add(new Contact(r.getLong(1), r.getString(2), r.getString(3)));
        } catch (SQLException e) { System.out.println("DB error: " + e.getMessage()); }
        return l;
    }

    static synchronized void addAlert(String owner, Alert a) {
        try {
            if (c != null) {
                try (PreparedStatement p = c.prepareStatement("INSERT INTO alerts(user_name,type,risk,severity,details,owner) VALUES(?,?,?,?,?,?)")) {
                    p.setString(1, a.user()); p.setString(2, a.type()); p.setDouble(3, a.risk());
                    p.setString(4, a.severity()); p.setString(5, a.details()); p.setString(6, owner); p.executeUpdate();
                }
            } else C_ALERT(owner, a);
        } catch (SQLException e) { System.out.println("DB error: " + e.getMessage()); }
    }

    static void C_ALERT(String owner, Alert a) {
        A.computeIfAbsent(owner, k -> new ArrayList<>()).add(new Alert(ids.incrementAndGet(),
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM HH:mm:ss")), a.user(), a.type(), a.risk(), a.severity(), a.details()));
    }

    static synchronized List<Alert> alerts(String owner) {
        List<Alert> l = new ArrayList<>();
        if (c == null) {
            List<Alert> m = A.getOrDefault(owner, List.of());
            for (int i = m.size() - 1; i >= 0 && l.size() < 50; i--) l.add(m.get(i));
            return l;
        }
        try (PreparedStatement p = c.prepareStatement("SELECT id,created_at,user_name,type,risk,severity,details FROM alerts WHERE owner=? ORDER BY id DESC LIMIT 50")) {
            p.setString(1, owner);
            ResultSet r = p.executeQuery();
            while (r.next()) l.add(new Alert(r.getLong(1), r.getString(2), r.getString(3), r.getString(4), r.getDouble(5), r.getString(6), r.getString(7)));
        } catch (SQLException e) { System.out.println("DB error: " + e.getMessage()); }
        return l;
    }
}
