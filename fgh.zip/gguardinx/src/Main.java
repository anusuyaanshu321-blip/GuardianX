import com.sun.net.httpserver.*;
import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import java.util.stream.*;

public class Main {
    static EmergencyModel model;

    public static void main(String[] args) throws Exception {
        Db.init();
        model = new EmergencyModel();
        HttpServer s = HttpServer.create(new InetSocketAddress(8080), 0);
        s.createContext("/api/register", Main::register);
        s.createContext("/api/login", Main::login);
        s.createContext("/api/logout", Main::logout);
        s.createContext("/api/predict", auth(Main::predict));
        s.createContext("/api/alerts", auth((x, o) -> json(x, 200, alertsJson(o))));
        s.createContext("/api/contacts", auth(Main::contacts));
        s.createContext("/api/stats", auth((x, o) -> json(x, 200, statsJson(o))));
        s.createContext("/", Main::staticFile);
        s.start();
        System.out.println("GuardianX running at http://localhost:8080");
    }

    static final Map<String, String[]> sessions = new java.util.concurrent.ConcurrentHashMap<>();

    interface UserHandler { void handle(HttpExchange x, String owner) throws IOException; }

    /** Requires a valid login token; passes the logged-in user's email (owner) to the handler. */
    static HttpHandler auth(UserHandler h) {
        return x -> {
            String t = x.getRequestHeaders().getFirst("X-Token");
            String[] u = t == null ? null : sessions.get(t);
            if (u == null) { json(x, 401, "{\"error\":\"Login required\"}"); return; }
            h.handle(x, u[0]);
        };
    }

    static void register(HttpExchange x) throws IOException {
        String b = body(x), n = str(b, "name", "").trim(), e = str(b, "email", "").trim().toLowerCase(), p = str(b, "password", "");
        if (n.isEmpty() || !e.contains("@") || p.length() < 6) { json(x, 400, "{\"error\":\"Enter name, a valid email and a password of 6+ characters\"}"); return; }
        if (!Db.addUser(n, e, p)) { json(x, 409, "{\"error\":\"Email already registered\"}"); return; }
        startSession(x, e, n);
    }

    static void login(HttpExchange x) throws IOException {
        String b = body(x);
        String em = str(b, "email", "").trim().toLowerCase(), name = Db.checkUser(em, str(b, "password", ""));
        if (name == null) { json(x, 401, "{\"error\":\"Invalid email or password\"}"); return; }
        startSession(x, em, name);
    }

    static void logout(HttpExchange x) throws IOException {
        String t = x.getRequestHeaders().getFirst("X-Token");
        if (t != null) sessions.remove(t);
        json(x, 200, "{\"ok\":true}");
    }

    static void startSession(HttpExchange x, String email, String name) throws IOException {
        String t = UUID.randomUUID().toString();
        sessions.put(t, new String[]{email, name});
        json(x, 200, "{\"token\":\"" + t + "\",\"name\":\"" + esc(name) + "\"}");
    }

    static void predict(HttpExchange x, String owner) throws IOException {
        if (!x.getRequestMethod().equals("POST")) { json(x, 405, "{\"error\":\"POST only\"}"); return; }
        String b = body(x);
        double[] f = {num(b, "heartRate", 75), num(b, "spo2", 97), num(b, "temp", 36.8), num(b, "impactG", 1), num(b, "motionless", 0)};
        String user = str(b, "user", "User");
        double risk = model.predict(f);
        String type = model.classify(f);
        String sev = risk >= 0.85 ? "HIGH" : risk >= 0.6 ? "MEDIUM" : "LOW";
        boolean alert = risk >= 0.6;
        int notified = 0;
        if (alert) {
            String d = String.format(Locale.US, "HR %.0f, SpO2 %.0f%%, Temp %.1fC, Impact %.1fg, Still %.0fs", f[0], f[1], f[2], f[3], f[4]);
            Db.addAlert(owner, new Alert(0, "", user, type, risk, sev, d));
            List<Contact> cs = Db.contacts(owner);
            // Hook point: replace this println with an SMS/email API call (Twilio, SMTP, etc.)
            for (Contact c : cs) System.out.println("[ALERT SENT] to " + c.name() + " (" + c.phone() + "): " + sev + " - " + type + " for " + user);
            notified = cs.size();
        }
        json(x, 200, String.format(Locale.US, "{\"risk\":%.4f,\"severity\":\"%s\",\"type\":\"%s\",\"alert\":%b,\"notified\":%d}", risk, sev, type, alert, notified));
    }

    static void contacts(HttpExchange x, String owner) throws IOException {
        if (x.getRequestMethod().equals("POST")) {
            String b = body(x);
            String n = str(b, "name", ""), p = str(b, "phone", "");
            if (!n.isBlank() && !p.isBlank()) Db.addContact(owner, n.trim(), p.trim());
        }
        json(x, 200, "[" + Db.contacts(owner).stream().map(c -> String.format("{\"id\":%d,\"name\":\"%s\",\"phone\":\"%s\"}", c.id(), esc(c.name()), esc(c.phone()))).collect(Collectors.joining(",")) + "]");
    }

    static String alertsJson(String o) {
        return "[" + Db.alerts(o).stream().map(a -> String.format(Locale.US,
                "{\"id\":%d,\"time\":\"%s\",\"user\":\"%s\",\"type\":\"%s\",\"risk\":%.3f,\"severity\":\"%s\",\"details\":\"%s\"}",
                a.id(), esc(a.time()), esc(a.user()), esc(a.type()), a.risk(), a.severity(), esc(a.details()))).collect(Collectors.joining(",")) + "]";
    }

    static String statsJson(String o) {
        List<Alert> l = Db.alerts(o);
        long hi = l.stream().filter(a -> a.severity().equals("HIGH")).count();
        long me = l.stream().filter(a -> a.severity().equals("MEDIUM")).count();
        return String.format("{\"total\":%d,\"high\":%d,\"medium\":%d,\"contacts\":%d}", l.size(), hi, me, Db.contacts(o).size());
    }

    static void staticFile(HttpExchange x) throws IOException {
        String p = x.getRequestURI().getPath();
        if (p.equals("/")) p = "/index.html";
        Path f = Paths.get("web", p).normalize();
        if (!f.startsWith("web") || !Files.isRegularFile(f)) { json(x, 404, "{\"error\":\"not found\"}"); return; }
        String t = p.endsWith(".css") ? "text/css" : p.endsWith(".js") ? "text/javascript" : "text/html";
        send(x, 200, t + "; charset=utf-8", Files.readAllBytes(f));
    }

    static void json(HttpExchange x, int code, String s) throws IOException { send(x, code, "application/json", s.getBytes(StandardCharsets.UTF_8)); }

    static void send(HttpExchange x, int code, String type, byte[] d) throws IOException {
        x.getResponseHeaders().set("Content-Type", type);
        x.sendResponseHeaders(code, d.length);
        try (OutputStream o = x.getResponseBody()) { o.write(d); }
    }

    static String body(HttpExchange x) throws IOException { return new String(x.getRequestBody().readAllBytes(), StandardCharsets.UTF_8); }
    static double num(String b, String k, double d) {
        Matcher m = Pattern.compile("\"" + k + "\"\\s*:\\s*\"?(-?[\\d.]+)").matcher(b);
        return m.find() ? Double.parseDouble(m.group(1)) : d;
    }
    static String str(String b, String k, String d) {
        Matcher m = Pattern.compile("\"" + k + "\"\\s*:\\s*\"([^\"]*)\"").matcher(b);
        return m.find() ? m.group(1) : d;
    }
    static String esc(String s) { return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " "); }
}
