import java.util.*;

/** Logistic-regression emergency predictor, trained at startup on synthetic vital-sign data. */
public class EmergencyModel {
    final int N = 5;
    double[] w = new double[N], mu = new double[N], sd = new double[N];
    double b;

    // Engineered features: deviation from normal for each reading (handles both too-high and too-low values)
    static double[] feats(double[] f) {
        return new double[]{Math.abs(f[0] - 75), Math.max(0, 97 - f[1]), Math.abs(f[2] - 36.8), f[3], f[4]};
    }

    public EmergencyModel() {
        Random r = new Random(42);
        int n = 4000;
        double[][] X = new double[n][];
        int[] y = new int[n];
        for (int i = 0; i < n; i++) {
            double[] f = {75 + 12 * r.nextGaussian(), 97 + 1.2 * r.nextGaussian(), 36.8 + 0.3 * r.nextGaussian(),
                    Math.abs(1 + 0.4 * r.nextGaussian()), -5 * Math.log(1 - r.nextDouble())};
            if (i % 2 == 0) {
                y[i] = 1;
                switch (r.nextInt(4)) {
                    case 0 -> { f[0] = r.nextBoolean() ? 150 + 15 * r.nextGaussian() : 38 + 6 * r.nextGaussian(); f[1] = 88 + 3 * r.nextGaussian(); }
                    case 1 -> { f[3] = 4 + 4 * r.nextDouble(); f[4] = 25 + 40 * r.nextDouble(); f[0] = 110 + 20 * r.nextGaussian(); }
                    case 2 -> f[1] = 80 + 7 * r.nextDouble();
                    default -> f[2] = r.nextBoolean() ? 39.8 + 0.8 * r.nextDouble() : 33.5 + 1.2 * r.nextDouble();
                }
            }
            X[i] = feats(f);
        }
        for (int j = 0; j < N; j++) {
            double s = 0, q = 0;
            for (double[] x : X) s += x[j];
            mu[j] = s / n;
            for (double[] x : X) q += (x[j] - mu[j]) * (x[j] - mu[j]);
            sd[j] = Math.sqrt(q / n) + 1e-9;
        }
        for (int ep = 0; ep < 400; ep++) {
            double[] g = new double[N];
            double gb = 0;
            for (int i = 0; i < n; i++) {
                double e = score(X[i]) - y[i];
                for (int j = 0; j < N; j++) g[j] += e * (X[i][j] - mu[j]) / sd[j];
                gb += e;
            }
            for (int j = 0; j < N; j++) w[j] -= 0.5 * g[j] / n;
            b -= 0.5 * gb / n;
        }
        int ok = 0;
        for (int i = 0; i < n; i++) if ((score(X[i]) >= 0.5 ? 1 : 0) == y[i]) ok++;
        System.out.printf("ML model trained. Training accuracy: %.1f%%%n", 100.0 * ok / n);
    }

    double score(double[] x) {
        double z = b;
        for (int j = 0; j < N; j++) z += w[j] * (x[j] - mu[j]) / sd[j];
        return 1 / (1 + Math.exp(-z));
    }

    /** f = {heartRate, spo2, temp, impactG, motionlessSec} -> emergency probability 0..1 */
    public double predict(double[] f) { return score(feats(f)); }

    public String classify(double[] f) {
        if (f[3] >= 3.5) return "Fall / Road Accident";
        if (f[1] < 92) return "Low Oxygen (Hypoxia)";
        if (f[0] > 130 || f[0] < 45) return "Cardiac Event";
        if (f[2] > 38.5 || f[2] < 35.5) return "Temperature Emergency";
        return "General Anomaly";
    }
}
