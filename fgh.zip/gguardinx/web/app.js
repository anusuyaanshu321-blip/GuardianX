const _f=window.fetch;window.fetch=(u,o={})=>{o.headers={...(o.headers||{}),"X-Token":localStorage.getItem("gx_token")||""};return _f(u,o).then(r=>{if(r.status==401){localStorage.removeItem("gx_token");location="login.html";}return r;});};
if(!localStorage.getItem("gx_token"))location="login.html";
const $=id=>document.getElementById(id);
const h=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const get=u=>fetch(u).then(r=>r.json());
const page=document.body.dataset.page,me=localStorage.getItem("gx_name")||"";

// shared sidebar
const NAV=[["index.html","📊 Dashboard","dashboard"],["monitor.html","📡 Live Monitor","monitor"],["alerts.html","🚨 Alerts","alerts"],["contacts.html","👥 Contacts","contacts"]];
$("nav").innerHTML=`<div class="brand">Guardian<span>X</span></div>`+NAV.map(([u,t,p])=>`<a href="${u}" class="${p==page?"on":""}">${t}</a>`).join("")+`<div class="bot">👤 ${h(me)}<button id="logout">Logout</button></div>`;
$("logout").onclick=async()=>{await fetch("/api/logout",{method:"POST"});localStorage.removeItem("gx_token");location="login.html";};

// alerts table (dashboard + alerts pages)
let ALERTS=[],flt="ALL";
function drawAlerts(){
  const tb=$("alerts"),n=+tb.dataset.max;
  tb.innerHTML=ALERTS.filter(a=>flt=="ALL"||a.severity==flt).slice(0,n).map(x=>`<tr><td><span class="tag ${x.severity}">${x.severity}</span></td><td>${h(x.type)}</td><td>${h(x.user)}</td><td>${Math.round(x.risk*100)}%</td><td>${h(x.details)}</td><td>${h(x.time)}</td></tr>`).join("")||"<tr><td colspan=6>No alerts yet.</td></tr>";
}
const loadAlerts=async()=>{ALERTS=await get("/api/alerts");drawAlerts();};

if(page=="dashboard"){
  const t=async()=>{const s=await get("/api/stats");for(const k in s)$("s_"+k).textContent=s[k];loadAlerts();};
  t();setInterval(t,5000);
}
if(page=="alerts"){
  loadAlerts();setInterval(loadAlerts,5000);
  $("filters").onclick=e=>{if(e.target.dataset.f){flt=e.target.dataset.f;drawAlerts();}};
}
if(page=="contacts"){
  const load=async()=>{const c=await get("/api/contacts");$("contacts").innerHTML=c.map(x=>`<li>${h(x.name)}<span>${h(x.phone)}</span></li>`).join("")||"<li><span>No contacts yet – add one below.</span></li>";};
  $("add").onclick=async()=>{await fetch("/api/contacts",{method:"POST",body:JSON.stringify({name:$("cname").value,phone:$("cphone").value})});$("cname").value=$("cphone").value="";load();};
  load();
}
if(page=="monitor"){
  const F=[["heartRate","Heart rate (bpm)",30,200,75,1],["spo2","Blood oxygen SpO₂ (%)",70,100,97,1],["temp","Body temperature (°C)",33,42,36.8,0.1],["impactG","Impact force (g)",0,10,1,0.1],["motionless","Motionless time (s)",0,120,0,1]];
  const P={Normal:[75,97,36.8,1,2],Cardiac:[165,89,37.2,1,10],Accident:[115,95,36.8,6.5,45],"Low oxygen":[95,82,36.9,1,5]};
  $("user").value=me;
  $("sliders").innerHTML=F.map(([k,l,mn,mx,v,st])=>`<label>${l}: <b id="v_${k}">${v}</b><input type="range" id="${k}" min="${mn}" max="${mx}" step="${st}" value="${v}"></label>`).join("");
  F.forEach(([k])=>$(k).oninput=()=>$("v_"+k).textContent=$(k).value);
  const setVals=a=>F.forEach(([k],i)=>{$(k).value=a[i];$("v_"+k).textContent=a[i];});
  $("presets").innerHTML=Object.keys(P).map(n=>`<button data-n="${n}">${n}</button>`).join("");
  $("presets").onclick=e=>{const n=e.target.dataset.n;if(n)setVals(P[n]);};
  async function analyze(){
    const body={user:$("user").value||"User"};F.forEach(([k])=>body[k]=+$(k).value);
    try{
      const r=await(await fetch("/api/predict",{method:"POST",body:JSON.stringify(body)})).json(),pct=Math.round(r.risk*100);
      $("bar").style.width=pct+"%";$("bar").style.background=r.severity=="HIGH"?"#e0262f":r.severity=="MEDIUM"?"#f39c12":"#2ecc71";
      $("result").className="result "+r.severity;
      $("rtext").textContent=r.alert?`🚨 ${r.type} – risk ${pct}% (${r.severity}). Alert sent to ${r.notified} contact(s).`:`✅ Risk ${pct}% – no emergency detected.`;
    }catch(e){$("rtext").textContent="Cannot reach backend. Is the Java server running?";}
  }
  $("run").onclick=analyze;
  let timer=null;
  $("liveBtn").onclick=()=>{
    if(timer){clearInterval(timer);timer=null;$("liveBtn").textContent="Start Live Monitoring";return;}
    $("liveBtn").textContent="Stop Live Monitoring";
    timer=setInterval(()=>{
      const ns=Object.keys(P),n=Math.random()<0.25?ns[1+Math.floor(Math.random()*(ns.length-1))]:"Normal";
      setVals(P[n].map((v,i)=>+(v*(1+(Math.random()-.5)*.06)).toFixed(F[i][5]<1?1:0)));analyze();
    },4000);
  };
}
